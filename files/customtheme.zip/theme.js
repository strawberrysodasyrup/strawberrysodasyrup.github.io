$(document).on(':storyready', function() {
    const styleEl = document.getElementById('style-module-theme');

    const themeOverrides = {
'--000': '#FFFFFF',
'--100': '#F1F1F1',
'--150': '#FFE1E7',
'--200': '#F9C2DA',
'--300': '#FFFFFF',
'--400': '#999999',
'--500': '#FFF8FA',
'--600': '#FE699A',
'--700': '#AD496A',
'--750': '#15070C',
'--800': '#000000',
'--850': '#000000',
'--900': '#000000',
'--red': '#ec3535',
'--pink': '#FD42AC',
'--pink-secondary': '#d67caf',
'--purple': '#80f',
'--purple-secondary': '#aa4bc8',
'--blue': '#5E7EDE',
'--blue-secondary': '#6BA9CB',
'--teal': '#7FCCCC',
'--green': '#6BCF46',
'--green-secondary': '#7caf7c',
'--lime': '#44e342',
'--orange': '#f28500',
'--brown': '#4c2217',
'--black': '#929292',
'--yellow': '#ffd700',
'--gold': 'hsl(46deg 71% 68%)',
'--silver': 'silver',
'--lewd': '#E83A6B',
'--defiant': '#D20C0C',
'--meek': '#E864A6',
'--brat': '#CD1FAD',
'--relaxed': '#88A0C7',
'--anxious': '#751635',
'--veteran': '#BA82E3',
'--methodical': '#DD7191',
'--scarred': '#DD7C45',
'--tattooed': '#458F93',
'--manager': '#6FA1D0',
'--link': '#E45D8A',
'--link-hover': 'rgb(171 43 97)',
'--danger': '#710909',
'--tooltip-background': '#1a1919',
'--tooltip-border': '#000000'
    };

    if (styleEl && styleEl.sheet) {
        for (const [variable, value] of Object.entries(themeOverrides)) {
            styleEl.sheet.cssRules[0].style.setProperty(variable, value);
        }
    }
});