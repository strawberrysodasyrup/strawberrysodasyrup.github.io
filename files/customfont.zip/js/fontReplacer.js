$(document).on(':storyready', function() {
    const style = document.createElement('style');
    style.textContent = `
        @font-face {
            font-family: '[name]';
            src: url('data:font/truetype;charset=utf-8;base64,YOUR_BASE64_STRING_HERE') format('truetype');
            font-weight: normal;
            font-style: normal;
        }
        
        .Arial {
            font-family: '[name]', Arial, Helvetica, sans-serif;
        }
    `;
    document.head.appendChild(style);
    
    console.log('Custom font embedded and Arial replaced');
});