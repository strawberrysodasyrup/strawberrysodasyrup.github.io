(function () {
    'use strict';

    function onEveryPassage() {
        const vars = State.variables;
        if (!vars) return;

        // --- Temple vow protection ---
        const virginity = vars.player?.virginity;
        if (virginity) {
            const desc = Object.getOwnPropertyDescriptor(virginity, 'temple');
            if (!desc || !desc.set || desc.get?.toString().indexOf('return true') === -1) {
                Object.defineProperty(virginity, 'temple', {
                    get: function () { return true; },
                    set: function (_val) { /* blocked */ },
                    configurable: true,
                    enumerable: true
                });
            }
        }

        // --- Fallen angel prevention ---
        if (vars.fallenangel > 0) {
            vars.fallenangel = 0;
        }

        if (vars.angel >= 6) {
            vars.angel = 5;
        }

        // --- Restore angel visuals ---
        if (vars.transformationParts) {
            if (vars.transformationParts.fallenAngel) {
                vars.transformationParts.fallenAngel.halo = "disabled";
                vars.transformationParts.fallenAngel.wings = "disabled";
            }
            if (vars.transformationParts.angel) {
                if (vars.transformationParts.angel.wings === "disabled") {
                    vars.transformationParts.angel.wings = "default";
                }
                if (vars.transformationParts.angel.halo === "disabled") {
                    vars.transformationParts.angel.halo = "default";
                }
            }
        }
    }

    $(document).on(':passagestart', onEveryPassage);

})();